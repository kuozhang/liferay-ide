package com.liferay.ide.tests;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.filter.FilterChain;
import javax.portlet.filter.FilterConfig;
import javax.portlet.filter.ResourceFilter;;

public class ResourceFilterImpl implements ResourceFilter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(FilterConfig arg0) throws PortletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ResourceRequest arg0, ResourceResponse arg1,
			FilterChain arg2) throws IOException, PortletException {
		// TODO Auto-generated method stub
		
	}

}

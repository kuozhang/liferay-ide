package com.liferay.ide.tests;

import javax.portlet.GenericPortlet;

public class GenericPortletImpl extends GenericPortlet {

}
